#-*- coding:utf-8 -*-
import sys,os
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
#sys.path.append("D:\\office\\appiumatom")
from utils.readini import Readini

class GetByLocal():
    def __init__(self,driver):
        self.driver = driver
    def get_element(self,key):
        read = Readini()
        local = read.get_value(key)
        if local != None:
            by = local.split('>')[0]
            local_by = local.split('>')[1]
            try:
                if by == "id":
                    return self.driver.find_element_by_id(local_by)
                elif by == "className":
                    return self.driver.find_element_by_class_name(local_by)
                else:
                    return self.driver.find_element_by_xpath(local_by)
            except:
                return None
        else:
            return None