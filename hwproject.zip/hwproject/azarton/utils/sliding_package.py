#-*- coding:utf-8 -*-
import sys,os
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from base.base_driver import BaseDriver
class SlidingPackage():
    def get_driver(self):
        self.driver = BaseDriver().android_driver()
    #获取屏幕size
    def get_size(self):
        size = self.driver.get_window_size()
        print(size) #返回一个dict
        self.width = size['width']
        self.heigth = size['height']
        print("宽度:"+self.width,"长度:"+self.heigth)
    '''
    #参数1：driver
    参数2：t，是持续时间
    参数3：n，是滑动次数    
    '''
    #向上滑动
    def swipe_up(self,t=500,n=1):
        x1 = self.width * 0.5 #x横坐标
        y1 = self.heigth * 0.75 #起点y坐标
        y2 = self.heigth * 0.25 #终点y坐标
        for i in range(n):
            self.driver.swipe(x1,y1,x1,y2,t)
    #向下滑动
    def swipe_down(self,t=500,n=1):
        x1 = self.width * 0.5   #x为横坐标
        y1 = self.heigth * 0.25 #y1 为开始纵坐标
        y2 = self.heigth * 0.75 #y2 为终点纵坐标
        for i in range(n):
            self.driver.swipe(x1,y1,x1,y2,t)
    #向左滑动
    def swipe_left(self,t=500,n=1):
        y1 = self.heigth * 0.5  #y1为纵坐标
        x1 = self.width * 0.25  #x1为开始横坐标
        x2 = self.width * 0.75  #x2为终点横坐标
        for i in range(n):
            self.driver.swipe(y1,x1,y1,x2,t)

    #向右滑动
    def swipe_right(self,t=500,n=1):
        y1 = self.heigth * 0.5  #y1为纵坐标
        x1 = self.width * 0.75  #x1为开始横坐标
        x2 = self.width * 0.25  #x2为终点横坐标
        for i in range(n):
            self.driver.swipe(y1,x1,y1,x2,t)


if __name__ == '__main__':
    sl = SlidingPackage()
    sl.get_size()