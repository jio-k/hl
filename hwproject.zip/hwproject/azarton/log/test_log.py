#-*- coding:utf-8 -*-
import logging,datetime,os
class TestLog():
    def __init__(self):
        self.logger = logging.getLogger()   #获取log对象
        self.logger.setLevel(logging.DEBUG) #设置bug等级DEBUG:最详细的日志信息 info:通常只记录关键节点
        clonse = logging.StreamHandler() #日志消息输出到stream（指定日志输出目标），如std.out,std.err 或任何file-like对象
        self.logger.addFilter(clonse)#把流添加进来，这样就能输出到控制台了
        self.logger.debug("text") #输出内容

        #用当前时间，命名log文件名称
            #1，获取当前的绝对路径
        dir_log = os.path.abspath(__file__)
            #2获取当前目录的上级路径
        base_dir = os.path.dirname(dir_log)
            #获取到最终路径
        log_file = os.path.join(base_dir,"logs")
            #4获取当前时间用来命名
        date_name = datetime.datetime.now().strftime("%Y-%m-%d")+'.log'
        #最终路径+时间命名喝起来
        log_name = log_file+"/"+date_name
        print(log_name)

        #设置一个地址把log传入到地址里面
        self.file_path = logging.FileHandler(log_name,'a',encoding="utf-8")
        #设置要输出的log信息
        formatter = logging.Formatter("时间：""%(asctime)s"+" 文件名:""%(filename)s-----> %(funcName)s %(levelno)s:%(levelname)s------->%(message)s")
        #self.logger.setLevel(logging.info())
        self.file_path.setFormatter(formatter) #写入到file_path文件里面
        self.logger.addHandler(self.file_path) #将写入的file_path文件里面的东西 文件里面
        self.logger.debug("text") #写入的内容
        clonse.close() #把流关闭
        self.logger.removeHandler(clonse) #把log关闭

    def get_log(self):
        return self.logger

    def close_clonse(self):
        self.file_path.close()
        self.logger.removeHandler(self.file_path)

if __name__ == '__main__':
    t = TestLog()
    log = t.get_log()
    log.debug("kkkkk")
    t.close_clonse()