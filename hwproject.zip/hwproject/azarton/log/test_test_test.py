#-*- coding:utf-8 -*-
import os
import datetime
dir_log = os.path.abspath(__file__)
base_dir = os.path.dirname(dir_log)
log_dir =os.path.join(base_dir, "logs")
log_name = datetime.datetime.now().strftime("%Y-%m-%d")+".log"
log_path = log_dir+'/'+log_name
print(log_path)