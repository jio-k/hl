#-*- coding:utf-8 -*-
from appium import webdriver
import os
class BaseDriver():

    def android_driver(self):
        caps = {}
        devices_infos = os.popen('adb devices').read()
        print(devices_infos)
        devices_udid = devices_infos.split(" ")[-1].split('\t')[-2].split('\n')[-1]
        caps["platformName"] = "Android"
        caps["deviceName"] = devices_udid
        #caps["appPackage"] = "com.azarton.cam " #日本com.atom.cam wyze:com.hualai
        caps["app"] = "D:\\Program Files\\apk\\azarton_0_7_1_release.apk"
        caps["appWaitActivity"] = "com.hualai.cam.home.SmartHomeMainActivity" 
                                    #登录页com.hualai.cam.home.user.activity.LogInActivity
                                  #登录之后com.hualai.cam.home.SmartHomeMainActivity
        caps["automationName"] = "uiautomator1" #automationName版本
        caps["autoGrantPermissions"] = "true" #有需要获取权限的弹窗默认点击确定
        caps["unicodeKeyboard"] = True
        #caps['uuid'] = '3458553639393498'
        caps["noReset"] = True # true:不重新安装APP，false:重新安装app

        self.driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub",caps)
        self.driver.implicitly_wait(5)
        #print(driver)
        return self.driver
    # def get_size(self):
    #     size = self.driver.get_window_size()
    #     print(size) #返回一个dict
    #     self.width = size['width']
    #     self.heigth = size['height']
        #宽度:1080 长度:2016

        '''
        #参数1：driver
        参数2：t，是持续时间
        参数3：n，是滑动次数    
        '''
        # 向左滑动 从513-363 y378
    # def swipe_left(self, t):
    #     y1 = self.heigth * 0.19  # y1为纵坐标
    #     x1 = self.width * 0.48  # x1为开始横坐标
    #     x2 = self.width * 0.33  # x2为终点横坐标
    #     #for i in range(n):
    #     self.driver.swipe(y1, x1, y1, x2, t)
    #     print("滑动方向")
    #     self.driver.implicitly_wait(5)

    # def scoll_page(self):
    #     sleep(5)
    #     start_element = self.driver.find_element_by_id("com.azarton.cam:id/wyze_all_device_list_camera_name")
    #     end_element = self.driver.find_element_by_id("com.azarton.cam:id/wyze_all_device_list_camera_iv_icon")
    #
    #     print("start_element:"+start_element.text)
    #     print("end_element:"+end_element)
    #     self.driver.scroll(start_element,end_element,3000)
    #     sleep(5)

# if __name__ == "__main__":
    # bd = BaseDriver()
    # bd.android_driver()
    # bd.get_size()
    # bd.scoll_page(1000)
