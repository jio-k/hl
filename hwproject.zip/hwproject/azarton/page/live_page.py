#-*- coding:utf-8 -*-
import sys,os
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from page.login_page import LoginPage
from appium.webdriver.common.touch_action import TouchAction
class LivePage(LoginPage):

    #进入实时浏览获取一个id用来判断进入是否成功
    def get_live_photo_id(self):
        photo_id = self.get_by_local.get_element("live_photo").get_attribute("resourceId")
        return photo_id

    #点击右上角返回按钮
    def get_live_back_devices(self):
        back_devices = self.get_by_local.get_element("live_rerurn_home").click()
        return back_devices

    #进入设置页
    def get_live_open_settings(self):
        open_settings = self.get_by_local.get_element("live_setting").click()
        return open_settings

    #拍照
    def get_live_photo(self):
        live_photo = self.get_by_local.get_element("live_photo").click()
        return live_photo
    #录像
    def get_live_record(self):
        live_record = self.get_by_local.get_element("live_record").click()
        return live_record
    #speak长按
    def get_live_speak(self):
        action = TouchAction(self.driver)
        live_speak = self.get_by_local.get_element("live_speak")
        action.long_press(live_speak).wait(3000).perform()

    #长按之后允许手机进行录像权限

    #打开声音按钮
    def get_live_voice(self):
        live_voice = self.get_by_local.get_element("live_voice").click()
        return live_voice

    #分辨率切换按钮
    def get_live_resolving_power(self):
        resolving_power = self.get_by_local.get_element("live_resolving_power").click()
        return resolving_power
    #hd，sd，360p
    def get_live_hd(self):
        live_hd = self.get_by_local.get_element("live_hd").click()
        return live_hd
    def get_live_sd(self):
        live_sd = self.get_by_local.get_element("live_sd").click()
        return live_sd
    def get_live_little_sd(self):
        live_little_sd = self.get_by_local.get_element("live_little_sd").click()
        return live_little_sd

    #设备列表全屏
    def get_live_Full_screen(self):
        live_Full_screen = self.get_by_local.get_element("live_Full_screen").click()
        return live_Full_screen

    #进入回放
    def get_live_history(self):
        live_history = self.get_by_local.get_element("live_history").click()
        return live_history

    #进入相册
    def get_live_album(self):
        live_album = self.get_by_local.get_element("live_album").click()
        return live_album

    #进入延时摄影
    def get_live_time_lapse(self):
        live_time_lapse = self.get_by_local.get_element("live_album").click()
        return live_time_lapse
    #关机
    def get_live_tv_off(self):
        live_tv_off = self.get_by_local.get_element("live_tv_off").click()
        return live_tv_off

    #开机
