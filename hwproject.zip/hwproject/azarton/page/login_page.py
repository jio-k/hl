#-*- coding:utf-8 -*-
import sys,os
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from utils.get_by_local import GetByLocal
from base.base_drive import BaseDriver

class LoginPage():
    #定义一个变量，用来记录__new__方法返回的第一个地址值
    # first_address = None
    # #用一个变量记录__init__内容是否已经被执行过
    # label = False
    #
    # #2重新new方法
    # def __new__(cls, *args, **kwargs):
    #     #判断如果是第一次就给对象分配一个空间，并且记录它的引用
    #     #如何不是第一次，就返回第一次记录的引用
    #
    #     if cls.first_address is None:
    #         cls.first_address = super().__new__(cls)
    #     return cls.first_address
    def __init__(self):
        base_drive = BaseDriver()
        self.driver = base_drive.android_driver()
        get_by_local = GetByLocal(self.driver)
        self.get_by_local = get_by_local(self.driver)
        #判断是否初始化了实例属性，如果没有就初始化实例属性，如果有就直接结束
        # if LoginPage.label:
        #     return
        # self.attribute = attribute_value
        # LoginPage.label = True
        # if LoginPage.label:
        #     return
        # LoginPage.label = True

    # def start_app(self):
    #
    #     self.get_by_local = GetByLocal(self.driver)
    '''
    # 获取用户名元素
    # '''
    # def get_username_element(self,username):
    #     username =  self.get_by_local.get_element("username")
    #     send_username = username.send_keys(username)
    #     return  send_username
    #
    # '''
    # 获取密码元素
    # '''
    # def get_password_element(self):
    #     return self.get_by_local.get_element("password")
    # '''
    # 获取登录元素
    # '''
    # def get_login_button_element(self):
    #     return self.get_by_local.get_element("login_button")

    #获取登录成功的标志
    def get_login_success(self):
        home_text = self.get_by_local.get_element("login_success").get_attribute("text")
        return  home_text
    '''
    首页列表
    '''
    #获取消息中心
    def get_test(self):
        return self.get_by_local.get_element("message_center")

if __name__ == "__main__":
    l = LoginPage()
    print(l.get_login_success())