#-*- coding:utf-8 -*-
import sys,os,time
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from page.login_page import LoginPage

class Devices(LoginPage):
    #点击消息中心
    # def __int__(self,drive):
    #     #self.login_page = LoginPage()
    #     self.get_by_local = GetByLocal(drive)

    def get_click_news(self):
        Message_center = self.get_by_local.get_element("message_center").click()
        return Message_center
    #点击一屏多画
    def get_click_one_screenid(self):
        one_screenid = self.get_by_local.get_element("one_screenid").click()
        return one_screenid

    #点击添加设备
    def get_click_add_device(self):
        add_device = self.get_by_local.get_element("add_device").click()
        return add_device

    #点击设备,进入实时浏览
    def get_click_device(self):
        click_device = self.get_by_local.get_element("click_device").click()
        return click_device

    #点击设备开关
    def get_click_device_off(self):
        self.get_by_local.get_element("device_off").click()
        #return device_off
    #获取设备开关状态
    def get_device_off_on(self):
        device_off_on = self.get_by_local.get_element("device_off")
        return device_off_on.get_attribute("")


    #左滑点击分享

    #左滑点击命名

    #点击商城
    def get_click_device_off(self):
        device_off = self.get_by_local.get_element("device_off").click()
        return device_off

    #点击个人中心
    def get_click_device_off(self):
        device_off = self.get_by_local.get_element("account_click").click()
        return device_off


if __name__ == '__main__':
    d = Devices()
    time.sleep(3)
    d.get_click_device()