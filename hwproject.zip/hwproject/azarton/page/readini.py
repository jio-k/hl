#-*- coding:utf-8 -*-
import configparser
class Readini():
    def __init__(self,file_path=None):
        if file_path == None:
            self.file_path = '/config/LocalElement.ini'
        else:
            self.file_path = file_path
        self.data = self.read_ini()
    
    #读取配置文件的方法
    def read_ini(self):
        cf = configparser.ConfigParser()
        cf.read(self.file_path,encoding='UTF-8')
        return cf

    #通过key获取对应的value
    def get_value(self, key, section=None):
        if section == None:
            section = 'login_element'
        try:
            value = self.data.get(section, key)
        except:
            value = None
        return value

    # def get_value(self, session, key):
    #     logging.info("get value: [" + session + "] - [" + key + "] from " + self.file_path)
    #     try:
    #         value = self.data.get(session, key)
    #     except:
    #         logging.error("获取元素出现了错误，请检查传入的session和key是否正确：session: " + session + "  key:" + key)
    #         value = None
    #     return value


if __name__ == "__main__":
    ri = Readini()
    print (ri.get_value("login_success","login_element"))