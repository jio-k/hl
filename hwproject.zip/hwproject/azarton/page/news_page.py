#-*- coding:utf-8 -*-
import LoginPage

class NewPage(LoginPage):

    #点击添加设备
    def get_add_devices(self):
        pass
    #点击删除

    #长按查看全选

    #点击进入
