#-*- coding:utf-8 -*-
class SettingsPage():
    pass
