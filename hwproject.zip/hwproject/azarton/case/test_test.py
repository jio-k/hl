#-*-coding:utf-8 -*-
import pytest

# class Testtest():
#     def test_login(self):
#         print("测试登录功能")
#
# if __name__ == '__main__':
#     command_line = ["-s", "D:\\office\\appiumatom\\case\\test_test.py", "--alluredir=report"]
#     pytest.main(command_line)

# class A():
#     def prt(self):
#         print("输出A")
#
# class c(A):
#     def prt(self):
#         print("输出a")
#
# class b(A):
#     def prt(self):
#         print("输出b")
# class d:
#     def prt(self):
#         print("输出d")
#
# def test(arg):
#     arg.prt()
#
# a = A()
# c = c()
# b = b()
# d = d()
#
#
# test(a)
# test(c)
# test(b)
# test(d)
# dict1 = {"age":"18","sex":"man"}
#
# # for k,u in dict1.items():
# #     print(k,u)
#
# #print (len(dict1))
# print(dict1["age"])

# def sum_number(*args):
#     total = 0
#     for k in args:
#         total += k
#     return total
#
# total = sum_number(1,2)
# print(total)
# 3
#
# def count_student(**kwargs):
#     for k,u in kwargs.items():
#         print("{0}:{1}".format(k,u))
#
# count_student(math='kw',logic='emily')
#
#

#
#def output_letter(letter):
#     return [l for l in letter if 'k' in l]
#
# print(output_letter(["keuie","did","klok"]))


# a= lambda l:[item*item for item in l]
#
# print(a([1,2,3,4]))

# my_list = [1,2,3]
# print(dir(my_list))
# print(dir(my_list).__class__)
# print(inspen)
# def outer():
#     cheer = 'hello'
#     def inner(name):
#         return cheer + name
#     return inner
#
# print(outer()("：kk"))

# import time
#
# #加一个时间
# def recode_time(func):
#     print("start time {}".format(time.strftime("%Y-%M-%D %H:%M:%S",time.localtime()) ))
#     def wrapper(*kwargs):
#         return func(*kwargs)
#     print("end time {}".format(time.strftime("%y-%m-%d %H:%M:%S",time.localtime()) ))
#     return wrapper()
#
# @recode_time
# def sum(*kwargs):
#     total = 0
#     for ele in kwargs:
#         total = total + ele
#     return total
# if __name__ == "__main__":
#     #注意此次无须再写record_time了，这样有利于大家把关注点放在功能函数本身。
#     print(sum(1,2,3,4))
# if __name__ == '__main__':
#     pytest.main([__file__])
#print(0 or 1)
# import sys,os
# base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(base_dir)
#from case.
# import os,sys
# import time
# import pytest
# import allure
# base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(base_dir)
# from page.login_page import LoginPage
# from page.devices_page import Devices
# from page.live_page import LivePage
# from log.test_log import TestLog
# log = TestLog()
# logger = log.get_log()
#
# device_page = Devices()
#
# time.sleep(2)
# live_video = device_page.get_click_device()
# 判断是否有成功进入实时浏览页面

# class father():
#
#     def call_children(self):
#         child_method = getattr(self, 'out')# 获取子类的out()方法
#         child_method() # 执行子类的out()方法
#
# class children(father):
#     def out(self):
#         print ("hehe")
#
# child = children()
# print(child.call_children())
import unittest
class TestSample(unittest.TestCase):
    #类共享的fixture，在整个测试类执行过程中仅仅执行一次，需加装饰器@classmethod
    @classmethod
    def setUpClass(cls):
        print('整个测试类只执行一次 -- Start')
    #测试用例fixture
    def setUp(self):
        print('每个测试开始前执行一次')
    # 测试用例默认以test开头
    def test_equal(self):
        self.assertEqual(1, 1)
    def test_not_equal(self):
        self.assertNotEqual(1, 0)
    #测试用例fixture
    def tearDown(self):
        print('每个测试结束后执行一次')
    #类共享的fixture，在整个测试类执行过程中仅仅执行一次，需加装饰器@classmethod
    @classmethod
    def tearDownClass(cls):
        print('整个测试类只执行一次 -- End')
if __name__ == '__main__':
    unittest.main()