import threading
# class Singleton(object):
#     _instance_lock = threading.Lock()
#
#     def __init__(self):
#         pass
#
#
#     def __new__(cls, *args, **kwargs):
#         if not hasattr(Singleton, "_instance"):
#             with Singleton._instance_lock:
#                 if not hasattr(Singleton, "_instance"):
#                     Singleton._instance = object.__new__(cls)
#         return Singleton._instance
#
# obj1 = Singleton()
# obj2 = Singleton()
# print(obj1,obj2)
#
# def task(arg):
#     obj = Singleton()
#     print(obj)
#
# for i in range(10):
#     t = threading.Thread(target=task,args=[i,])
#     t.start()
#
# from wsgiref.simple_server import make_server
# class DbHelper(object):
#     _instance = None

# class Demo(object):
#     #定义一个变量，用来记录__new__方法返回的第一个地址值
#     first_address = None
#
#     #(1)用一个变量记录__init__内容是否已经执行过
#     label = False
#
#     #2重写__new__方法
#     def __new__(cls, *args, **kwargs):
#         #判断如果是第一次就给对象分配一个空间，并且记录它的引用
#         #如果不是第一次，就返回第一次记录的引用
#         if cls.first_address is None:
#             cls.first_address = super().__new__(cls)
#
#         return cls.first_address
#
#     #2,__init__方法的写法
#     def __init__(self,attribute_value):
#         #判断是否初始化了实例属性，如果没有就初始化实例属性，否则直接结束方法
#         if Demo.label:
#             return
#         self.attribute = attribute_value
#         Demo.label = True
#
#     def test(self):
#         print(self.attribute)
#
# a1 = Demo("a444")
# print(a1)
#
# a2 = Demo("a2")
# print(a2)
#
# a1.test()
# a2.test()


class MusicPlayer(object):
    count = 0  # 类属性

    instance = None  # 记录第一个被创建对象的引用
    init_flag = False  # 记录是否执行过初始化动作

    def __new__(cls, *args, **kwargs):
        print("\n==> 对象 %d" % cls.count)
        if cls.instance is None:
            cls.instance = super().__new__(cls)  # 必须带cls
        return cls.instance

    def __init__(self):
        MusicPlayer.count += 1

        if MusicPlayer.init_flag:
            return
        print("初始化播放器")
        MusicPlayer.init_flag = True


player1 = MusicPlayer()
print(player1)

player2 = MusicPlayer()
