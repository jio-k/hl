# -*- coding: utf-8 -*-
from appium import webdriver
import time,os


def get_phoneUuid():
    devices_infos = os.popen('adb devices').read()
    print(devices_infos)
    # print(type(devices_infos))
    devices_udid = devices_infos.split(" ")[-1].split('\t')[-2].split('\n')[-1]
    # print(devices_udid)
    return devices_udid

driver_caps = {}
driver_caps['platformName'] = "Android"
driver_caps['platfoeVersion'] = "9"
driver_caps['deviceName'] = "xiaomi"

# app信息
# driver_caps['appPackage'] = 'com.wyze.android.toycar'
# driver_caps['appActivity'] = 'com.hualai.car.MainActivity'
#
driver_caps['appPackage'] = 'com.azarton.cam'
driver_caps['appActivity'] = 'com.hualai.cam.home.user.activity.LogInActivity'
driver_caps['udid'] = get_phoneUuid()

# 不清除账户信息
driver_caps['noReset'] = True
# 声明手机驱动对象
driver = webdriver.Remote('127.0.0.1:4723/wd/hub', driver_caps)
print(driver.page_source)