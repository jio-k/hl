#-*-coding:utf-8 -*-
import os,sys
import time
import pytest
import allure
base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from page.login_page import LoginPage
from page.devices_page import Devices
from page.live_page import LivePage
from base.base_drive import BaseDriver
from log.test_log import TestLog

log = TestLog()
logger = log.get_log()
@allure.feature("azarton 主流程测试")
class TestAzartonCamrea():
    '''
    azarton ui自动化case
    '''
    #登录
    # def test_login(self):
    #    # get_by_local = GetByLocal(self.driver)
    #    # 输入用户名
    #     self.handle_login.send_username("ouqingwei@hualaikeji.com")
    #     print("test 2222")
    #     self.handle_login.send_password("11111111")
    #     self.handle_login.click_login_button()
    #     #获取到登录成功的Home
    #     home = self.handle_login.get_login_success()
    #     #判断是否登录成功
    #     assert "Home" in home.get_attribute("resource-id")

    # global device_page,live_page
    # device_page = Devices()
    # live_page = LivePage()
    @allure.story('case1:验证进入列表页')
    def test_01_start(self,driver):
        self.base_drive = BaseDriver()
        self.driver = self.base_drive.android_driver()
        self.login_page = LoginPage(self.driver)
        #启动app
        #self.login_page.start_app()
        #获取到登录成功的Home
        logger.debug("this is Azarton")
        log.close_clonse()
        home_text = self.login_page.get_login_success()
        #判断是否登录成功
        # print ("test："+home_text)
        print(home_text)
        assert "Home" in home_text
    # @allure.story('case2:进入消息中心删除')
    # def test_opne_news(self):
    #     self.devices_page.get_click_news()


    '''
    进入实时浏览
    '''
    def test_02_enter_live(self):
        self.device_page = Devices()
        self.live_page = LivePage()
        live_video = self.device_page.get_click_device()

        time.sleep(2)
        live_photo_id = self.live_page.get_live_photo_id()
        #判断是否有成功进入实时浏览页面
        assert live_video.get_attribute("resourceId") in live_photo_id
        print(live_photo_id)
        #返回实时浏览页
        self.live_page.get_back_devices()

    '''
    操作关机
    '''

    # def test_03_off_devices(self):
    #     devices_status = self.device_page.get_click_device_off()
    #     try:
    #         if devices_status == "":
    #             device_off = self.device_page.get_click_device_off()
    #             self.test_enter_live()
    #         else:
    #             print("该设备目前处于关机状态，无法操作关机！")
    #     except:
    #         print("关机操作异常！")


    '''
    操作开机
    '''
    # def test_04_on_devices(self):
    #     devices_status = self.get_device_off_on()
    #     try:
    #         if devices_status == "":
    #             device_off = self.device_page.get_click_device_off()
    #             live_video = self.device_page.get_click_click_device()
    #
    #         else:
    #             print("该设备目前处于开机状态，无法操作开机！")
    #     except:
    #         print("开机操作异常！")

    # def teardown(self):
    #     pass
    #     #self.driver.quit()

if __name__ == "__main__":

    # pytest.main(['-s','./test_azarton_camera.py','--alluredir','D:/office/appiumatom/temp/xml'])
    # os.system("allure generate D:/office/appiumatom/temp/xml -o D:/office/appiumatom/temp/report --clean")
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pytest.main(['-s','./test_azarton_camera.py','--alluredir',base_dir+'/temp/xml'])
    os.system("allure generate "+base_dir+"/temp/xml -o "+base_dir+"/temp/report --clean")